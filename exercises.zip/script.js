const getStartedBtn = document.querySelector('.btn-get-started');

getStartedBtn.addEventListener('click', () => {
  // Redirect to the main page
  window.location.href = "main.html"; 
});