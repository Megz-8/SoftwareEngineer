// Smooth scrolling for anchor links
document.querySelectorAll('nav ul li a').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();

    const targetId = this.getAttribute('href').substring(1);
    const targetElement = document.getElementById(targetId);
    
    window.scrollTo({
      top: targetElement.offsetTop - 60, // Adjusted for header height
      behavior: 'smooth'
    });
  });
});

// Highlight active navigation item on scroll
const sections = document.querySelectorAll('section');
const navLinks = document.querySelectorAll('nav ul li a');

window.addEventListener('scroll', () => {
  let current = '';
  
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.offsetHeight;
    if (pageYOffset >= sectionTop - 60 && pageYOffset < sectionTop + sectionHeight - 60) {
      current = section.getAttribute('id');
    }
  });

  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href').includes(current)) {
      link.classList.add('active');
    }
  });
});

// "Back to top" button functionality
const backToTopButton = document.createElement('button');
backToTopButton.innerText = "↑ Back to Top";
backToTopButton.classList.add('back-to-top');
document.body.appendChild(backToTopButton);

backToTopButton.addEventListener('click', () => {
  window.scrollTo({
    top: 0,
    behavior: 'smooth'
  });
});

window.addEventListener('scroll', () => {
  if (window.scrollY > 200) {
    backToTopButton.style.display = 'block';
  } else {
    backToTopButton.style.display = 'none';
  }
});

// Add styles for the "back to top" button dynamically
const style = document.createElement('style');
style.innerHTML = `
  .back-to-top {
    position: fixed;
    bottom: 30px;
    right: 30px;
    background-color: #16a085;
    color: white;
    padding: 10px 15px;
    font-size: 1.5em;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    display: none;
  }

  .back-to-top:hover {
    background-color: #1abc9c;
  }

  .active {
    color: #e74c3c;
  }
`;
document.head.appendChild(style);
